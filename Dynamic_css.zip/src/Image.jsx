import React from 'react';
import side from './assets/side.jpg';
import './image.css';

const Image = () => {
  return (
    <div className='image_css'>
        <img src={side} />
    </div>
  )
}

export default Image