import logo from './logo.svg';
import './App.css';
import LoginPage from './LoginPage'
import Image from './Image';

function App() {
  return (
    <>
    <div className='layout'>
      <div className='login_page_css'>
        <LoginPage />
      </div>
      <div className='image_page_css display_block'>
        <Image />
      </div>
    </div>
      
    </>
  );
}

export default App; 
