import React from 'react'
import google from './assets/google.jpg';
import './loginPage.css';
import './image.css';
import side from './assets/side.jpg';

const LoginPage = () => {
  return (
    <>
        <div className='form'>
            <div className='heading'>
                <h1>Welcome back</h1>
                <p className=''>Welcome back! Please enter your details.</p>
            </div>
            <div className='form_section'>
                <p className='form_section_p'>Email</p>
                <input className='input_type' type='email' placeholder='Enter your email' />
                <p className='form_section_p'>Password</p>
                <input className='input_type' type="password" placeholder="******" />
            </div>
            <div className='remember_forgot_psw'>
                <span className='text check-setting'><input type='checkbox'></input>Remember me</span>
                <span className='text'>Forgot password</span>
            </div>
            <div className='btn-grp'>
                <button className='btn-color'>Sign in</button>
                <button className='btn-without-color'><span><img src="http://assets.stickpng.com/images/5847f9cbcef1014c0b5e48c8.png"></img></span>Sign in with Google</button>
            </div>
            <div className='signUp-text'>
                <span>Don’t have an account?</span> <span className='sign_up_color'>Sign up fo free!</span>
            </div>
        </div>
    </>
  )
}

export default LoginPage;